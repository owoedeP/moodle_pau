<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Block definition class for the block_pluginname plugin.
 *
 * @package   block_pluginname
 * @copyright Year, You Name <your@email.address>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

class block_texteditor extends block_base {

    /**
     * Initialises the block.
     *
     * @return void
     */
    public function init() {
        $this->title = get_string('pluginame', 'block_texteditor');
    }

    /**
     * Gets the block contents.
     *
     * @return string The block HTML.
     */
    public function get_content() {
        global  $DB, $USER, $OUTPUT, $CFG, $PAGE;

        if ($this->content !== null) {
            return $this->content;
        }

        if (empty($this->instance)) {
            $this->content = '';
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->footer = '';


    
    $blockinstance = $this->instance;
    $userid = $USER->id;

    $user_customization = $DB->get_record('block_texteditor', 
    ['blockid' => $blockinstance->id, 'userid' => $userid]);

    if ($user_customization) {
        $html = $user_customization->html;
        $css = $user_customization->css;
    } else {
        $html = ''; // Provide default HTML
        $css = ''; // Provide default CSS
    }

    // Apply user-defined CSS to the HTML
    $htmlWithCSS = "<style>{$css}</style>{$html}";


        // Add logic here to define your template data or any other content.
        $data = [
            'htmlWithCSS' => $htmlWithCSS,
        ];
        $this->content->text = $OUTPUT->render_from_template('block_texteditor/content', $data);

        return $this->content;
    }

    /**
     * Defines in which pages this block can be added.
     *
     * @return array of the pages where the block can be added.
     */
    public function applicable_formats() {
        return [
            'all' => true
        ];
    }

    function _self_test() {
        return true;
      }
}