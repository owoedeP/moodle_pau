## v3.9.6 (2022-04-04)

* require removal 
* require removal 
* criteria count larger than 0 
* code review 
* Version update 


## v3.9.5 (2022-03-12)

* @covers 
* Version update 


## v3.9.4 (2022-02-26)

* mariadb 10 
* Version update 


## v3.9.3 (2022-01-10)

* php8.0 cron 
* MoodleInternalNotNeeded 
* Version update 


## v3.9.2 (2022-01-05)

* behat without reports 
* behat classic 
* coveralls 
* use use 
* namespace 
* Version update 


## v3.9.1 (2021-12-12)

* code coverage 
* code review 
* code fix 
* test namespacing 
* coverage 
* MDL-70197 
* code review 
* coverage.php 
* coverage.php 
* version update 


## v3.9.0 (2021-07-18)

* call_internal_method 
* version update 
* Readme 
* Actions 
* update Readme 
* code coverage 
* workflow 
* completion value used 
* workflow 
* drop 38 
* version update 
* version update 
* cron.yaml 
* cron.yaml 
* workflow 
* workflow php 8.0 
* workflow php 8.0 
* workflow php 8.0 
* workflow php 8.0 
* section 0 
* version update 
* Update version.php 
* mariadb 10.5 
* code review 
* version update 


## v3.8+ (2020-10-23)

* version update 
* cache nvm 
* behat tests 
* MOODLE_BRANCH=MOODLE_39_STABLE 
* moodlehq ci 
* plugin-ci ^3 
* plugin-ci ^3 
* plugin-ci ^3 
* plugin-ci ^3 
* MOODLE_310_STABLE 
* .package.json 
* 3.10 
* travis.com 
* travis 
* phpunit upgrade 
* version update 3.8+ 


