NOW BUY ALMOND PRO VERSION ! 
==================
https://almondthemes.lemonsqueezy.com/

ALMOND THEMES
==================
https://www.themesalmond.com/
https://shop.themesalmond.com/

THANK YOU SUPPORTING US !
==================
<a href="https://www.buymeacoffee.com/almondthemes" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

Theme Almondb 
==================
easy setup<br>
easy customization<br>

unlimited color<br>
40+ customizable blocks<br>
Hame page slider<br>
Info page plugin<br>

Version : 2022102200
=====================
- Categories to be displayed on the front page can be selected.
- Bugs fixed.

